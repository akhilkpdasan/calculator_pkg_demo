def cos(angle):
    print("Performing calculation...Will get back to you")
