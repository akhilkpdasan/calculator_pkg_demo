def divide(x, y):
    print("Performing calculation...Will get back to you")
